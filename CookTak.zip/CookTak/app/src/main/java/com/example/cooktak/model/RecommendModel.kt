package com.example.cooktak.model

data class RecommendModel(
    val img: Int,
    val name: String,
    val sub: String
)