package com.example.cooktak.model

data class barcodeModel(
    var KANProductCategoryCode: String = "",
    var code: String = "",
    var info: String = "",
    var photoLink: String? = "",
    var productName: String = "",
    var seller: String = "",
    var vendor: String = "",
    var weight: String = "",
    var weightAll: String = ""
)