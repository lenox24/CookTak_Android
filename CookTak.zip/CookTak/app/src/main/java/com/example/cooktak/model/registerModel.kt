package com.example.cooktak.model

data class registerModel(
    var email: String,
    var pwd: String,
    var nick: String,
    var age: Int,
    var gender: Int
)