package com.example.cooktak.model

data class searchModel(
    val title: String,
    val content: String,
    val img: Int
)