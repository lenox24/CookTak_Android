package com.example.cooktak.ui.Main.Barcode

import com.journeyapps.barcodescanner.CaptureActivity

class AnyOrientationCaptureActivity : CaptureActivity() {}