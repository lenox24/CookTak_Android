package com.example.cooktak.ui.Main.Community

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.cooktak.R

class CreateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create)
    }
}
