package com.example.cooktak.util

import android.support.multidex.MultiDexApplication

class App : MultiDexApplication() {
    override fun onCreate() {
        super.onCreate()
    }
}